/* 合成大OK · 游戏逻辑 + PBD 物理 + Canvas 渲染 + WebAudio 音效 */
/* =========================================================
 *  合成大OK —— 一张纸就能跑完的最小实现
 *  规则：同级别相撞 → 合成为高一级；顶到警戒线并停住 1.2 秒 → 结束
 *  物理：自己写的 PBD（位置约束），不依赖任何引擎
 * ======================================================= */
(function () {
  'use strict';

  /* ---------- 1. 参数 ---------- */
  const W = 380, H = 600;      // 逻辑坐标：所有物理量都在这个空间里算
  const WALL = 8;              // 墙厚
  const DROP_Y = 68;           // 待投放水果的悬停高度
  const DANGER_Y = 104;        // 警戒线

  const GRAVITY = 2400;        // px/s²
  const SUBSTEPS = 2;          // 每帧物理子步
  const ITER = 5;              // 每个子步的约束迭代次数
  const DROP_MS = 340;         // 两次投放的最小间隔
  const OVER_LIMIT = 1.2;      // 越线并静止多少秒判负
  const REST_SPEED = 140;      // 低于这个速度才算“卡住了”
  const PAD = 0.6;             // 合成接触容差 px

  const RESTITUTION = 0.30;    // 球球弹性
  const WALL_RESTITUTION = 0.40;
  const REST_THRESHOLD = 55;   // 撞击速度低于此值不反弹（堆叠才稳）
  const FRICTION = 0.94;

  // 11 级太多，这里留 9 级：核心是「链」这个概念，不是数量
  // file : assets/fruits/ 下的贴图；没有的话退回程序化圆球（c + e）
  const SPRITE_SCALE = 1.55;   // 贴图边长 = 2r × 1.55 × 档位系数
  const SHAPES = (typeof window !== 'undefined' && window.SUIKA_SHAPES) || [];
  const ASSET_VER = '5';       // 贴图换过就 +1，避免浏览器/托管用旧缓存
  const FRUITS = [
    { name: '葡萄',   r: 16, c: '#a578e0', e: '🍇', file: 'assets/fruits/01-grape.webp' },
    { name: '樱桃',   r: 22, c: '#e5484d', e: '🍒', file: 'assets/fruits/02-cherry.webp' },
    { name: '橘子',   r: 29, c: '#f5872b', e: '🍊', file: 'assets/fruits/03-orange.webp' },
    { name: '柠檬',   r: 37, c: '#e8c53c', e: '🍋', file: 'assets/fruits/04-lemon.webp' },
    { name: '猕猴桃', r: 45, c: '#8fbf45', e: '🥝', file: 'assets/fruits/05-kiwi.webp' },
    { name: '番茄',   r: 54, c: '#e2503c', e: '🍅', file: 'assets/fruits/06-tomato.webp' },
    { name: '桃子',   r: 64, c: '#f39aa4', e: '🍑', file: 'assets/fruits/07-peach.webp' },
    { name: '菠萝',   r: 76, c: '#e9b93f', e: '🍍', file: 'assets/fruits/08-pineapple.webp' },
    { name: '狂飙巨星',   r: 90, c: '#4fae57', e: '🍉', file: 'assets/fruits/09-watermelon.webp' }
  ];
  const MAX_TIER = FRUITS.length - 1;
  const SCORE = [0, 1, 3, 6, 10, 15, 21, 28, 36];   // 合成出第 n 级得几分（三角数）
  const SPAWN_TIERS = [0, 1, 2, 3, 4];
  const SPAWN_WEIGHTS = [0.28, 0.24, 0.20, 0.16, 0.12];
  const MAX_BONUS = 120;       // 两个狂飙巨星一起炸掉的奖励分

  const BEST_KEY  = 'suika.mini.best';
  const MUTE_KEY  = 'suika.mini.mute';
  const BOARD_KEY = 'suika.mini.board';

  /* ---------- 2. DOM ---------- */
  const $ = (id) => document.getElementById(id);

  const stage      = $('stage');
  const canvas     = $('c');
  const ctx        = canvas.getContext('2d');
  const nextCanvas = $('next');
  const nextCtx    = nextCanvas.getContext('2d');
  const chainCanvas = $('chain');
  const chainCtx   = chainCanvas.getContext('2d');

  const scoreEl = $('score');
  const bestEl  = $('best');
  const soundBtn = $('soundBtn');
  const resetBtn = $('resetBtn');
  const boardBtn = $('boardBtn');

  const modal      = $('boardModal');
  const boardList  = $('boardList');
  const boardClose = $('boardClose');
  const boardAgain = $('boardAgain');

  let scale = 1;

  function fit() {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width  = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
    scale = canvas.width / W;
  }

  /* ---------- 3. 存储 ----------
     localStorage 在 file://、隐私模式、“禁止所有 Cookie”、部分 App 内置浏览器里
     会直接抛异常。而它是在启动阶段读的 —— 一抛，整个脚本就停，页面一片空白，
     看起来就像“打不开”。所以先探一次，不行就退回内存存储。 */
  const Store = (() => {
    let ok = false;
    const mem = Object.create(null);
    try {
      const probe = '__suika_probe__';
      window.localStorage.setItem(probe, '1');
      window.localStorage.removeItem(probe);
      ok = true;
    } catch (e) {
      ok = false;
    }
    return {
      ok,
      get(k) {
        try {
          return ok ? window.localStorage.getItem(k) : (k in mem ? mem[k] : null);
        } catch (e) {
          return k in mem ? mem[k] : null;
        }
      },
      set(k, v) {
        try {
          if (ok) window.localStorage.setItem(k, String(v));
          else mem[k] = String(v);
        } catch (e) {
          mem[k] = String(v);
        }
      }
    };
  })();

  /* ---------- 4. 状态 ---------- */
  const state = {
    balls: [], particles: [], floats: [],
    score: 0, best: Number(Store.get(BEST_KEY) || 0),
    pending: 0, next: 0,
    aimX: W / 2, ready: true, cooldown: 0,
    over: false, ended: false, danger: false, flash: 0
  };

  function rand(a, b) { return a + Math.random() * (b - a); }
  function rollTier() {
    let r = Math.random(), acc = 0;
    for (let i = 0; i < SPAWN_TIERS.length; i++) {
      acc += SPAWN_WEIGHTS[i];
      if (r <= acc) return SPAWN_TIERS[i];
    }
    return 0;
  }

  /* ---------- 4. 音效（WebAudio 现场合成，无音频文件） ---------- */
  const Sound = {
    ctx: null,
    muted: Store.get(MUTE_KEY) === '1',

    ensure() {
      if (this.ctx) return this.ctx;
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { this.ctx = new AC(); } catch (e) { this.ctx = null; }
      return this.ctx;
    },

    tone(freq, freq2, dur, vol, type) {
      if (this.muted) return;
      const c = this.ensure();
      if (!c) return;
      if (c.state === 'suspended') c.resume();
      const t = c.currentTime;
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freq, t);
      if (freq2 && freq2 !== freq) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, freq2), t + dur);
      }
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(vol, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc.connect(gain);
      gain.connect(c.destination);
      osc.start(t);
      osc.stop(t + dur + 0.02);
    },

    drop()      { this.tone(340, 210, 0.09, 0.16, 'sine'); },
    merge(tier) { const f = 190 + tier * 42; this.tone(f, f * 1.6, 0.16, 0.20, 'triangle'); },
    bonus()     { this.tone(520, 900, 0.35, 0.22, 'triangle'); },
    over()      { this.tone(420, 110, 0.55, 0.20, 'sawtooth'); },

    toggle() {
      this.muted = !this.muted;
      Store.set(MUTE_KEY, this.muted ? '1' : '0');
      paintSound();
      if (!this.muted) { this.ensure(); this.tone(660, 880, 0.09, 0.14); }
      return this.muted;
    }
  };

  function paintSound() {
    if (!soundBtn) return;
    const ico = $('soundIco'), lbl = $('soundLbl');
    soundBtn.setAttribute('aria-pressed', Sound.muted ? 'false' : 'true');
    if (ico) ico.textContent = Sound.muted ? '🔇' : '🔊';
    if (lbl) lbl.textContent = Sound.muted ? '音效关' : '音效开';
  }

  /* ---------- 5. 刚体 ---------- */
  /* 贴图边长：碰撞体也按这个尺度生成，所以画面和碰撞严丝合缝 */
  function spriteBox(tier) {
    const r = FRUITS[tier].r;
    const boost = 1.15 - 0.15 * (r / FRUITS[MAX_TIER].r);
    return (r * 2) * SPRITE_SCALE * boost;
  }

  function shapeOf(tier) {
    const sh = SHAPES[tier];
    return (sh && sh.parts && sh.parts.length) ? sh : { rb: 0.62, parts: [[0, 0, 0.5]] };
  }

  function makeBall(x, y, tier, vx, vy) {
    const r = FRUITS[tier].r;
    const m = r * r;                    // 质量 ~ 面积
    const box = spriteBox(tier);
    const sh = shapeOf(tier);
    const parts = sh.parts.map((p) => ({ ox: p[0] * box, oy: p[1] * box, rr: p[2] * box }));

    let rb = 0, topExt = 0, botExt = 0, halfW = 0;
    for (const p of parts) {
      rb = Math.max(rb, Math.hypot(p.ox, p.oy) + p.rr);
      topExt = Math.max(topExt, -p.oy + p.rr);
      botExt = Math.max(botExt, p.oy + p.rr);
      halfW = Math.max(halfW, Math.abs(p.ox) + p.rr);
    }

    return {
      x, y, px: x, py: y,
      vx: vx || 0, vy: vy || 0, pvx: 0, pvy: 0,
      r, box, tier, m, invMass: 1 / m,
      parts, rb, topExt, botExt, halfW,
      dead: false, hit: false,
      landed: false, bornAt: performance.now(),
      overTime: 0, popAt: 0
    };
  }

  /* 只为了拿宽度，不建刚体 */
  const halfWCache = [];
  function halfWidthOf(tier) {
    if (halfWCache[tier] === undefined) {
      const box = spriteBox(tier), sh = shapeOf(tier);
      let w = 0;
      for (const p of sh.parts) w = Math.max(w, Math.abs(p[0] * box) + p[2] * box);
      halfWCache[tier] = w;
    }
    return halfWCache[tier];
  }

  /* ---------- 6. 物理核心（PBD） ---------- */
  function substep(dt) {
    const balls = state.balls;
    const contacts = [];
    const merges = [];

    // 6.1 积分：先按速度走一步，记下“走过的位置”
    for (const b of balls) {
      b.px = b.x; b.py = b.y;
      b.vy += GRAVITY * dt;
      b.pvx = b.vx; b.pvy = b.vy;      // 求解前的速度，弹性冲量要用
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.hit = false;
    }

    // 6.2 约束求解：反复把“穿模”推开
    for (let it = 0; it < ITER; it++) {
      /* 墙 / 地：每个子圆各自算穿透，取最深的那一处一次性推刚体 */
      for (const b of balls) {
        if (b.dead) continue;
        let pushL = 0, pushR = 0, pushF = 0;
        for (const p of b.parts) {
          const px = b.x + p.ox, py = b.y + p.oy;
          pushL = Math.max(pushL, WALL - (px - p.rr));
          pushR = Math.max(pushR, (px + p.rr) - (W - WALL));
          pushF = Math.max(pushF, (py + p.rr) - (H - WALL));
        }
        if (pushL || pushR || pushF) {
          b.x += pushL - pushR;
          b.y -= pushF;
          b.hit = true;
          if (it === 0) {
            if (pushL) contacts.push({ b, nx: 1, ny: 0 });
            if (pushR) contacts.push({ b, nx: -1, ny: 0 });
            if (pushF) contacts.push({ b, nx: 0, ny: -1 });
          }
        }
      }

      // 球球：两两求交，按逆质量分配推开量
      for (let i = 0; i < balls.length; i++) {
        const a = balls[i];
        if (a.dead) continue;
        for (let j = i + 1; j < balls.length; j++) {
          const b = balls[j];
          if (b.dead) continue;

          const dx = b.x - a.x, dy = b.y - a.y;
          const rbSum = a.rb + b.rb;
          if (dx * dx + dy * dy >= rbSum * rbSum) continue;   // 包围圆粗筛

          /* 子圆两两求交，取「陷得最深」的那一对作为接触点 */
          let gap = 1e9, nx = 0, ny = 0;
          for (const pa of a.parts) {
            const ax = a.x + pa.ox, ay = a.y + pa.oy;
            /* 粗筛：这个子圆离对方重心太远，整组跳过 */
            const fdx = b.x - ax, fdy = b.y - ay, far = b.rb + pa.rr;
            if (fdx * fdx + fdy * fdy >= far * far) continue;
            for (const pb of b.parts) {
              const bx = b.x + pb.ox, by = b.y + pb.oy;
              const ddx = bx - ax, ddy = by - ay;
              const sum = pa.rr + pb.rr;
              const d2 = ddx * ddx + ddy * ddy;
              if (d2 >= sum * sum) continue;
              const d = Math.sqrt(d2) || 1e-4;
              const g = d - sum;
              if (g < gap) { gap = g; nx = ddx / d; ny = ddy / d; }
            }
          }
          if (gap === 1e9) continue;

          // 同级 + 贴着 → 合成。只在第 0 次迭代判一次，避免重复合成
          if (it === 0 && a.tier === b.tier && gap <= PAD) {
            a.dead = true; b.dead = true;
            merges.push([a, b]);
            continue;
          }

          const corr = Math.min(-gap, 4) * 0.85;  // 单次只修 85%，留点余量防抖
          if (corr <= 0) continue;
          const invSum = a.invMass + b.invMass;
          const wa = a.invMass / invSum;
          a.x -= nx * corr * wa;  a.y -= ny * corr * wa;
          b.x += nx * corr * (1 - wa); b.y += ny * corr * (1 - wa);
          a.hit = b.hit = true;
          if (it === 0) contacts.push({ a, b, nx, ny });
        }
      }
    }

    // 6.3 收尾贴墙：球球分离可能把水果顶出墙外
    for (const b of balls) {
      if (b.dead) continue;
      b.x = Math.min(Math.max(b.x, WALL + b.halfW), W - WALL - b.halfW);
      if (b.y + b.botExt > H - WALL) b.y = H - WALL - b.botExt;
    }

    // 6.4 由位置差反推速度 —— PBD 的招牌动作
    const invDt = 1 / dt;
    for (const b of balls) {
      if (b.dead) continue;
      const dx = b.x - b.px, dy = b.y - b.py;
      b.vx = dx * invDt;
      b.vy = dy * invDt;
      if (b.hit) b.vx *= FRICTION;       // 接触时的切向摩擦
      if (!b.landed && (b.hit || performance.now() - b.bornAt > 900)) b.landed = true;
    }

    // 6.5 弹性冲量：把法向速度改写成 e × 撞前速度
    //     位置约束会吃掉法向速度，不补这一下，球就是“啪”地粘住，没有 Q 弹感
    for (const c of contacts) {
      if (c.b) {
        const b = c.b;
        if (b.dead) continue;
        const vnPre = b.pvx * c.nx + b.pvy * c.ny;
        if (vnPre < -REST_THRESHOLD) {
          const vnPost = b.vx * c.nx + b.vy * c.ny;
          const j = (-WALL_RESTITUTION * vnPre) - vnPost;
          if (j > 0) { b.vx += j * c.nx; b.vy += j * c.ny; }
        }
      } else {
        const a = c.a, b = c.b;
        if (a.dead || b.dead) continue;
        const vnPre = (a.pvx - b.pvx) * c.nx + (a.pvy - b.pvy) * c.ny;  // >0 相互靠近
        if (vnPre > REST_THRESHOLD) {
          const vnPost = (a.vx - b.vx) * c.nx + (a.vy - b.vy) * c.ny;
          const j = (vnPost + RESTITUTION * vnPre) / (a.invMass + b.invMass);
          if (j > 0) {
            a.vx -= j * a.invMass * c.nx; a.vy -= j * a.invMass * c.ny;
            b.vx += j * b.invMass * c.nx; b.vy += j * b.invMass * c.ny;
          }
        }
      }
    }

    if (merges.length) mergeAll(merges);
  }

  /* ---------- 7. 合成 ---------- */
  function mergeAll(merges) {
    for (const [a, b] of merges) {
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const tier = a.tier;

      if (tier >= MAX_TIER) {          // 已经最大了 → 炸掉
        addScore(MAX_BONUS);
        burst(mx, my, tier, 46);
        state.floats.push({ x: mx, y: my - 40, t: '💥 +' + MAX_BONUS, life: 1.4 });
        state.flash = 1;
        Sound.bonus();
        continue;
      }

      const nt = tier + 1;
      const nb = makeBall(mx, my, nt, (a.vx + b.vx) / 2, (a.vy + b.vy) / 2 - 60);
      // 贴墙合成时新球更大，先夹回场内，防止一出生就穿墙
      nb.x = Math.min(Math.max(nb.x, WALL + nb.halfW), W - WALL - nb.halfW);
      nb.y = Math.min(nb.y, H - WALL - nb.botExt);
      nb.landed = true;
      nb.popAt = performance.now();
      state.balls.push(nb);

      addScore(SCORE[nt], mx, my);
      burst(mx, my, nt, 6 + nt * 3);
      Sound.merge(nt);
      if (nt === MAX_TIER) state.flash = 1;
    }
    state.balls = state.balls.filter(b => !b.dead);
    drawNext();
  }

  function addScore(n, x, y) {
    state.score += n;
    if (state.score > state.best) {
      state.best = state.score;
      Store.set(BEST_KEY, state.best);
      bestEl.textContent = state.best;
    }
    scoreEl.textContent = state.score;
    bump(scoreEl);
    if (x !== undefined) state.floats.push({ x, y, t: '+' + n, life: 1 });
  }

  function bump(el) {
    if (!el) return;
    el.classList.remove('bump');
    void el.offsetWidth;          // 强制 reflow，让动画能重新触发
    el.classList.add('bump');
  }

  function burst(x, y, tier, n) {
    const c = FRUITS[Math.min(tier, MAX_TIER)].c;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = rand(60, 260);
      state.particles.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 60,
        r: rand(1.5, 4), life: 1, decay: rand(1.4, 2.4), c
      });
    }
    if (state.particles.length > 300) state.particles.splice(0, state.particles.length - 300);
  }

  /* ---------- 8. 投放 ---------- */
  function aimLimit(tier) {
    const w = halfWidthOf(tier);
    return [WALL + w + 1, W - WALL - w - 1];
  }

  function drop() {
    if (state.over || !state.ready) return;
    const [lo, hi] = aimLimit(state.pending);
    const x = Math.min(Math.max(state.aimX, lo), hi);
    state.balls.push(makeBall(x, DROP_Y, state.pending, 0, 120));
    state.ready = false;
    state.cooldown = DROP_MS / 1000;
    state.pending = state.next;
    state.next = rollTier();
    drawNext();
    Sound.drop();
  }

  /* ---------- 9. 判负 ---------- */
  function checkOver(dt) {
    let danger = false;
    for (const b of state.balls) {
      if (b.dead || !b.landed) continue;
      if (b.y - b.topExt < DANGER_Y) {
        danger = true;
        if (b.vx * b.vx + b.vy * b.vy < REST_SPEED * REST_SPEED) {
          b.overTime += dt;
          if (b.overTime > OVER_LIMIT) { endGame(); return; }
        } else {
          b.overTime = Math.max(0, b.overTime - dt * 2);
        }
      } else {
        b.overTime = Math.max(0, b.overTime - dt * 2);
        if (b.overTime > 0) danger = true;
      }
    }
    state.danger = danger;
  }

  function endGame() {
    if (state.ended) return;
    state.over = true;
    state.ended = true;
    Sound.over();
    saveScore(state.score);
  }

  function reset() {
    state.balls.length = 0;
    state.particles.length = 0;
    state.floats.length = 0;
    state.score = 0;
    state.over = false;
    state.ended = false;
    state.ready = true;
    state.cooldown = 0;
    state.danger = false;
    state.flash = 0;
    state.aimX = W / 2;
    state.pending = rollTier();
    state.next = rollTier();
    scoreEl.textContent = '0';
    bestEl.textContent = state.best;
    drawNext();
    closeBoard();
  }

  /* ---------- 10. 本机排行榜 ---------- */
  function readBoard() {
    try {
      const arr = JSON.parse(Store.get(BOARD_KEY) || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function saveScore(s) {
    if (!(s > 0)) return;
    const list = readBoard();
    list.push({ s, t: Date.now() });
    list.sort((a, b) => b.s - a.s);
    const top = list.slice(0, 10);
    Store.set(BOARD_KEY, JSON.stringify(top));
  }

  function fmtDate(ts) {
    const d = new Date(ts);
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return (d.getMonth() + 1) + '/' + d.getDate() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function renderBoard() {
    const list = readBoard();
    if (!list.length) {
      boardList.innerHTML = '<div class="board-empty">还没有成绩，先玩一局吧 🌱</div>';
      return;
    }
    // 只有数字和时间，不会有 HTML 注入
    boardList.innerHTML = list.map((row, i) =>
      '<div class="board-row' + (i === 0 ? ' is-top' : '') + '">' +
        '<span class="board-rank">' + (i + 1) + '</span>' +
        '<span class="board-score">' + row.s + '</span>' +
        '<span class="board-date">' + fmtDate(row.t) + '</span>' +
      '</div>'
    ).join('');
  }

  function openBoard() {
    renderBoard();
    modal.classList.add('show');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeBoard() {
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
  }

  /* ---------- 11. 绘制 ---------- */
  function drawFruit(c, x, y, r, tier, angle, sc) {
    const f = FRUITS[tier];
    c.save();
    c.translate(x, y);
    if (sc && sc !== 1) c.scale(sc, sc);

    /* 有贴图就画人物：居中、不裁圆、不旋转。
       边长和碰撞体用同一个 spriteBox()，所以画面 = 碰撞。 */
    if (f.img) {
      const h = spriteBox(tier) * (r / FRUITS[tier].r);
      c.drawImage(f.img, -h / 2, -h / 2, h, h);
      c.restore();
      return;
    }

    c.rotate(angle || 0);

    const g = c.createRadialGradient(-r * .34, -.4 * r, r * .12, 0, 0, r * 1.1);
    g.addColorStop(0, 'rgba(255,255,255,.55)');
    g.addColorStop(.55, 'rgba(255,255,255,0)');
    g.addColorStop(1, 'rgba(90,50,10,.20)');

    c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2);
    c.fillStyle = f.c; c.fill();
    c.fillStyle = g; c.fill();

    c.font = (r * 1.72 | 0) + 'px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(f.e, 0, r * .06);
    c.restore();
  }

  function drawBoard() {
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#fffaf0');
    bg.addColorStop(1, '#ffe7c6');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // 顶部投放区高光
    const top = ctx.createLinearGradient(0, 0, 0, 170);
    top.addColorStop(0, 'rgba(255,255,255,.75)');
    top.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = top;
    ctx.fillRect(0, 0, W, 170);

    ctx.strokeStyle = 'rgba(196,150,100,.45)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(WALL, 0); ctx.lineTo(WALL, H - WALL);
    ctx.lineTo(W - WALL, H - WALL); ctx.lineTo(W - WALL, 0);
    ctx.stroke();

    // 警戒线
    ctx.save();
    ctx.setLineDash([8, 8]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = state.danger
      ? 'rgba(255,70,70,' + (0.5 + 0.5 * Math.abs(Math.sin(performance.now() / 140))) + ')'
      : 'rgba(226,152,120,.5)';
    ctx.beginPath();
    ctx.moveTo(WALL, DANGER_Y); ctx.lineTo(W - WALL, DANGER_Y);
    ctx.stroke();
    ctx.restore();

    drawTopPreview();
  }

  /* 棋盘右上角的「下一个」：手机上侧栏被压成信息条，这里是唯一的提示 */
  function drawTopPreview() {
    const r = 15;
    const x = W - WALL - 30, y = 34;
    ctx.save();
    ctx.globalAlpha = .9;
    ctx.font = '600 11px "PingFang SC","Microsoft YaHei",system-ui,sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(150,110,80,.85)';
    ctx.fillText('下一个', x - r - 10, y);
    ctx.restore();
    drawFruit(ctx, x, y, r, state.next, 0, 1);
  }

  function drawBalls() {
    const now = performance.now();
    // 小的先画，大的压在上面
    const sorted = state.balls.slice().sort((a, b) => a.r - b.r);
    for (const b of sorted) {
      if (b.dead) continue;

      /* 地面投影只给程序化圆球用；人像贴图不加 ——
         那圈硬边椭圆会看起来像碰撞边缘（而且浮空时阴影错位）。 */
      if (!FRUITS[b.tier].img) {
        ctx.save();
        ctx.globalAlpha = .14;
        ctx.fillStyle = '#7a4a1e';
        ctx.beginPath();
        ctx.ellipse(b.x, H - WALL - 1, b.r * .85, Math.max(3, b.r * .16), 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      let sc = 1;
      if (b.popAt) {
        const t = (now - b.popAt) / 200;
        if (t < 1) sc = 1 + .26 * (1 - t);
        else b.popAt = 0;
      }
      drawFruit(ctx, b.x, b.y, b.r, b.tier, b.angle, sc);
    }
  }

  function drawAim() {
    if (state.over) return;
    const tier = state.pending, r = FRUITS[tier].r;
    const [lo, hi] = aimLimit(tier);
    const x = Math.min(Math.max(state.aimX, lo), hi);
    const bob = Math.sin(performance.now() / 320) * 2.5;

    if (state.ready) {
      ctx.save();
      ctx.setLineDash([5, 8]);
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(200,140,90,.45)';
      ctx.beginPath();
      ctx.moveTo(x, DROP_Y + r + 6); ctx.lineTo(x, H - WALL);
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    if (!state.ready) ctx.globalAlpha = .4;

    /* 人像比球高 1.35 倍，直接画会被画布顶边切头。
       持握时按「刚好放得下」缩一点，脚底位置不变；投放后恢复原尺寸。 */
    let rDraw = r;
    if (FRUITS[tier].img) {
      const room = 2 * (DROP_Y - 6);          // 落点上方能放下的高度
      const box = spriteBox(tier);
      if (box > room) rDraw = r * room / box; // 放不下就缩，仍然居中
    }
    drawFruit(ctx, x, DROP_Y + bob, rDraw, tier, 0, 1);
    ctx.restore();
  }

  function drawEffects(dt) {
    for (let i = state.particles.length - 1; i >= 0; i--) {
      const p = state.particles[i];
      p.vy += 1400 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= p.decay * dt;
      if (p.life <= 0) { state.particles.splice(i, 1); continue; }
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.fillStyle = p.c;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 18px system-ui, sans-serif';
    for (let i = state.floats.length - 1; i >= 0; i--) {
      const f = state.floats[i];
      f.life -= dt * 1.4;
      f.y -= 46 * dt;
      if (f.life <= 0) { state.floats.splice(i, 1); continue; }
      ctx.globalAlpha = Math.min(1, f.life);
      ctx.fillStyle = '#d2691e';
      ctx.strokeStyle = 'rgba(255,255,255,.8)';
      ctx.lineWidth = 3;
      ctx.strokeText(f.t, f.x, f.y);
      ctx.fillText(f.t, f.x, f.y);
    }
    ctx.globalAlpha = 1;

    if (state.flash > 0) {
      ctx.globalAlpha = Math.min(.55, state.flash);
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
      state.flash = Math.max(0, state.flash - dt * 2.5);
    }
  }

  function drawOver() {
    if (!state.over) return;
    ctx.fillStyle = 'rgba(60,30,10,.62)';
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 32px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillText('游戏结束', W / 2, H / 2 - 54);
    ctx.font = 'bold 48px system-ui, sans-serif';
    ctx.fillText(String(state.score), W / 2, H / 2 + 6);
    ctx.font = '13px system-ui, "Microsoft YaHei", sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,.8)';
    ctx.fillText('最高 ' + state.best + ' · 点击或按 R 重开', W / 2, H / 2 + 58);
  }

  /* 面板里的“下一个” */
  function drawNext() {
    if (!nextCanvas) return;
    const w = nextCanvas.width, h = nextCanvas.height;
    nextCtx.setTransform(1, 0, 0, 1, 0, 0);
    nextCtx.clearRect(0, 0, w, h);
    const tier = state.next;
    const r = FRUITS[tier].r;
    // 人像比球高（SPRITE_SCALE），面板里要留出头顶的空间
    const k = (Math.min(w, h) * (FRUITS[tier].img ? 0.30 : 0.42)) / r;
    drawFruit(nextCtx, w / 2, h / 2, r * k, tier, 0, 1);
  }

  /* 面板里的“合成表” */
  function drawChain() {
    if (!chainCanvas) return;
    const cw = chainCanvas.width, ch = chainCanvas.height;
    chainCtx.setTransform(1, 0, 0, 1, 0, 0);
    chainCtx.clearRect(0, 0, cw, ch);

    const slot = cw / FRUITS.length;
    const r = slot * 0.44;
    const cy = ch * 0.5;

    for (let i = 0; i < FRUITS.length; i++) {
      const x = slot * (i + 0.5);
      drawFruit(chainCtx, x, cy, r, i, 0, 1);
      if (i < FRUITS.length - 1) {
        chainCtx.save();
        chainCtx.globalAlpha = 0.45;
        chainCtx.fillStyle = '#b08a68';
        chainCtx.font = '600 ' + Math.round(ch * 0.2) + 'px system-ui, sans-serif';
        chainCtx.textAlign = 'center';
        chainCtx.textBaseline = 'middle';
        chainCtx.fillText('›', x + slot * 0.5, cy);
        chainCtx.restore();
      }
    }
  }

  function render(dt) {
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    drawBoard();
    drawBalls();
    drawAim();
    drawEffects(dt);
    drawOver();
  }

  /* 贴图：异步加载，到位后重画面板里的「下一个 / 合成表」。
     加载失败不影响玩，继续画程序化圆球，但会在页面底部报一句 */
  let spriteFails = 0;

  function loadSprites() {
    for (const f of FRUITS) {
      if (!f.file) continue;
      const img = new Image();
      img.onload = () => {
        const ready = () => { f.img = img; drawNext(); drawChain(); };
        /* 等 decode 完成再交给 drawImage，避免画出没解码完的半成品 */
        if (img.decode) img.decode().then(ready, ready);
        else ready();
      };
      img.onerror = () => {
        spriteFails++;
        if (window.console) console.warn('[suika] 贴图加载失败，回退圆球：' + f.file);
        warn('有 ' + spriteFails + ' 张人物贴图没加载出来，现在显示的是备用圆球。'
           + '检查 assets/fruits/ 目录有没有跟 index.html 一起上传。');
      };
      /* 单文件版里 file 是 data URI，不能再拼查询串 */
      img.src = f.file.indexOf('data:') === 0 ? f.file : f.file + '?v=' + ASSET_VER;
    }
  }

  /* 页面底部的提示条（index.html 里有 #fatal） */
  const fatalEl = document.getElementById('fatal');
  function warn(msg) {
    if (!fatalEl) return;
    fatalEl.textContent = msg;
    fatalEl.hidden = false;
  }

  /* ---------- 12. 主循环 ---------- */
  const FIXED = 1 / 60;
  let last = 0, acc = 0;

  /* 一个固定步长：物理 + 投放冷却 + 判负。
     单独拆出来，调试时可以直接 update(1/60) 把世界快进到稳定。 */
  function update(dt) {
    if (state.over) return;
    for (let s = 0; s < SUBSTEPS; s++) substep(dt / SUBSTEPS);
    if (state.cooldown > 0) {
      state.cooldown -= dt;
      if (state.cooldown <= 0) state.ready = true;
    }
    checkOver(dt);
  }

  function frame(now) {
    const raw = (now - last) / 1000;
    last = now;
    // 切后台回来时 raw 会很大，直接丢掉，否则水果会瞬移穿墙
    const dt = Math.min(raw, 0.1);

    if (!state.over) {
      acc += dt;
      let guard = 0;
      while (acc >= FIXED && guard++ < 5) {
        update(FIXED);
        acc -= FIXED;
      }
    }
    render(dt);
    requestAnimationFrame(frame);
  }

  /* ---------- 13. 输入 ---------- */
  function toX(clientX) {
    const rect = canvas.getBoundingClientRect();
    return ((clientX - rect.left) / rect.width) * W;
  }

  let aiming = false;

  canvas.addEventListener('pointerdown', (e) => {
    if (state.over) { reset(); return; }
    aiming = true;
    canvas.setPointerCapture(e.pointerId);
    state.aimX = toX(e.clientX);
    if (e.pointerType === 'mouse') drop();       // 鼠标：按下即投
  });

  canvas.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'mouse' || aiming) state.aimX = toX(e.clientX);
  });

  canvas.addEventListener('pointerup', (e) => {
    if (aiming && e.pointerType !== 'mouse') {   // 触屏：松手才投
      state.aimX = toX(e.clientX);
      drop();
    }
    aiming = false;
  });

  canvas.addEventListener('pointercancel', () => { aiming = false; });

  function isFormField(e) {
    const t = e.target;
    const tag = (t.tagName || '').toLowerCase();
    return tag === 'button' || tag === 'input' || tag === 'textarea';
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeBoard(); return; }
    if (isFormField(e)) return;      // 焦点在按钮上时，空格/回车交给按钮
    if (e.key === 'ArrowLeft')  { state.aimX -= 7; e.preventDefault(); }
    if (e.key === 'ArrowRight') { state.aimX += 7; e.preventDefault(); }
    if (e.key === ' ' || e.key === 'Enter') { drop(); e.preventDefault(); }
    if (e.key === 'r' || e.key === 'R') { reset(); }
  });

  /* ---------- 14. 面板按钮 ---------- */
  resetBtn.addEventListener('click', reset);
  soundBtn.addEventListener('click', () => Sound.toggle());
  boardBtn.addEventListener('click', openBoard);
  boardClose.addEventListener('click', closeBoard);
  boardAgain.addEventListener('click', reset);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeBoard(); });

  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', () => setTimeout(fit, 120));

  /* ---------- 15. 启动 ---------- */
  fit();
  if (window.ResizeObserver) new ResizeObserver(fit).observe(stage);

  state.pending = rollTier();
  state.next = rollTier();
  paintSound();
  drawChain();
  drawNext();
  loadSprites();               // 贴图到位前先画圆球，到了自动替换
  scoreEl.textContent = '0';
  bestEl.textContent = state.best;

  requestAnimationFrame((t) => { last = t; requestAnimationFrame(frame); });

  // 调试钩子：控制台里能摸到状态
  window.__SUIKA__ = { state, reset, drop, FRUITS, Sound, endGame, checkOver, update, render, makeBall, spriteBox };
})();

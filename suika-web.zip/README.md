# 合成大OK · 网页版

一个可以直接部署的静态小游戏：拖动瞄准、松手投放，相同的撞在一起合成更大的一只。
**纯 HTML + CSS + JavaScript，零依赖、零构建、不需要后端**，把整个文件夹丢到任何静态托管上就能玩。

## 目录

```
suika-web/
├── index.html              页面结构：棋盘 + 侧边面板 + 排行榜弹窗
├── manifest.webmanifest    加到主屏幕用（名称、图标、主题色）
├── .nojekyll               GitHub Pages 用，别删
├── assets/
│   ├── style.css           全部样式（含手机断点）
│   ├── game.js             游戏逻辑 + PBD 物理 + Canvas 渲染 + WebAudio 音效
│   ├── icon.svg            favicon（矢量）
│   ├── icon-192.png        安卓主屏图标
│   ├── icon-512.png        安卓主屏图标（大）
│   ├── icon-maskable-512.png  安卓自适应图标（内容收在安全区内）
│   ├── apple-touch-icon.png   iOS 主屏图标
│   ├── og.jpg              分享卡片（1200×630）
│   └── fruits/             9 级贴图，256×256 透明底 WebP
│       ├── 01-grape.webp       葡萄    r=16
│       ├── 02-cherry.webp      樱桃    r=22
│       ├── 03-orange.webp      橘子    r=29
│       ├── 04-lemon.webp       柠檬    r=37
│       ├── 05-kiwi.webp        猕猴桃  r=45
│       ├── 06-tomato.webp      番茄    r=54
│       ├── 07-peach.webp       桃子    r=64
│       ├── 08-pineapple.webp   菠萝    r=76
│       ├── 09-watermelon.webp  狂飙巨星  r=82
│       └── 10-ultimate.webp    原型钛体  r=96
└── README.md
```

## 本地预览

双击 `index.html` 就能玩（`file://` 协议下也正常，排行榜存在浏览器本地）。

想更接近线上环境，起个静态服务：

```bash
cd suika-web
python -m http.server 8000
# 打开 http://localhost:8000
```

## 部署（三选一）

**GitHub Pages**

1. 新建仓库，把 `suika-web/` 里的内容推到根目录（`index.html` 必须在根上）；
2. 仓库 Settings → Pages → Source 选 `Deploy from a branch`，分支 `main`、目录 `/ (root)`；
3. 等一两分钟，地址是 `https://<用户名>.github.io/<仓库名>/`。

仓库根目录的 `.nojekyll` 别删——没有它，GitHub 会跑一遍 Jekyll，
下划线开头的文件会被吞掉。

**Netlify Drop**

把 `suika-web.zip` 直接拖到 <https://app.netlify.com/drop>，几秒后给你一个 https 地址。
（zip 里必须是 `index.html` 在最外层，不能套一层文件夹——这个包已经是这样打的。）

**Vercel / Cloudflare Pages**

都是「导入仓库 → 框架选 Other / 静态 → 输出目录填 `.`」，不需要构建命令。

## 部署后建议改两处

`index.html` 的 `<head>` 里，社交分享用的地址目前是空的／相对的，有些抓取器不认：

```html
<meta property="og:url" content="https://你的域名/">
<meta property="og:image" content="https://你的域名/assets/og.jpg">
```

顺手把 `<meta name="author" content="">` 填上。其余都可以不动。

## 数据存在哪

全部在浏览器本地（`localStorage`），换设备/清缓存就没了：

| 键 | 内容 |
| --- | --- |
| `suika.mini.best` | 最高分 |
| `suika.mini.mute` | 静音开关 |
| `suika.mini.board` | 本机前 10 局成绩（换后端就换掉这一段） |

想做成真正的在线榜，可以照原作者的思路接一个免后端 key-value 服务
（他用的是 App Inventor 的 TinyWebDB，`Access-Control-Allow-Origin: *`），
或者自己写个 Cloudflare Worker + KV，只改 `game.js` 里的 `saveScore` / `renderBoard` 两个函数。

## 想改点什么

| 想改 | 去哪 |
| --- | --- |
| 重力、弹性、摩擦、投放间隔、判负时间 | `assets/game.js` 顶部常量区 |
| 水果种类、半径、颜色、表情 | `assets/game.js` 的 `FRUITS` |
| 加分规则 | `assets/game.js` 的 `SCORE`（三角数）和 `MAX_BONUS` |
| 配色、圆角、玻璃感 | `assets/style.css` 的 `:root` 变量和 `.panel` |
| 手机版式（顶部信息条宽度、棋盘高度） | `assets/style.css` 的 `@media (max-width: 860px)` |
| 文案 | `index.html` 里直接改 |

## 换贴图

10 级现在全部用贴图（`assets/fruits/`），换任意一级只要替换同名文件，或者改 `game.js` 的 `FRUITS`：

1. 图片规格：**正方形、透明底、主体居中占长边约 92%**，256×256 或 512×512 的 PNG/WebP；
2. 丢进 `assets/fruits/`，按 `NN-名字.webp` 命名，或在 `FRUITS` 里改 `file` 字段：

```js
{ name: '葡萄', r: 16, c: '#a578e0', e: '🍇', file: 'assets/fruits/01-grape.webp' },
```

绘制方式：**整幅人物、不裁圆、不旋转**，高度 = `2r × SPRITE_SCALE`（当前 1.35），
**脚底对齐球的底部**（`y = +r`）。所以人比球高、头会冒出球顶，但永远不会陷进地板。
`SPRITE_SCALE` 就是"人比球大多少"的旋钮，调小更收敛、调大自然更夸张。

删掉 `file` 或图片加载失败，就自动退回程序化圆球（`c` 配色 + `e` 表情），不会白屏。

素材处理这条链（抠底 → 底部对齐裁方 → 烤暗边 → WebP）在仓库外的 `art-src/build_tiers.py`，
换整批图可以直接改 `NAMES` 重跑。

注意最小一级整个只有 **32 px**，全身像基本看不清；这是尺寸决定的，换图也救不回来。

## 兼容性

桌面 Chrome / Edge / Firefox / Safari 最新两个大版本，iOS Safari 15+、Android Chrome。
用到的都是 `pointer events`、`aspect-ratio`、`backdrop-filter`、`100dvh`（带 `100vh` 回退）。
没有做 Service Worker，所以**不能离线**，安卓上也不会弹「安装」——但 iOS/安卓都可以用
「添加到主屏幕」当 App 打开（manifest 和 apple-touch-icon 已经配好）。

## 说明

玩法和合成链参考了《合成大西瓜》(Suika Game) 一类开源实现，代码是这份最小版本自己的。
仅供学习娱乐。
